import firebase from "firebase";

 const firebaseConfig = {
    apiKey: "AIzaSyCPA3vZL72Hg--WPnDItFftOsvYniB9FVw",
    authDomain: "tienda-1c26f.firebaseapp.com",
    databaseURL: "https://tienda-1c26f-default-rtdb.firebaseio.com",
    projectId: "tienda-1c26f",
    storageBucket: "tienda-1c26f.appspot.com",
    messagingSenderId: "704546554934",
    appId: "1:704546554934:web:a9505f99a3f257cf36c497",
    measurementId: "G-TD39KEHPJ7"
  };


  // export default firebaseConfig;
 firebase.initializeApp(firebaseConfig);
 firebase.analytics();
 
 export default firebase;
  // const db = fb.firestore();
