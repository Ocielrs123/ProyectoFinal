import React from 'react';
import {
  BrowserRouter as Router,
  Route,
  Redirect,
  Switch
} from 'react-router-dom';
import Pagina2 from './Components/Pages/Pagina2';
import Pagina3 from './Components/Pages/Pagina3';
import Home from './Components/Pages/Home';
import CarouselI from './Components/Carousel/Carousel';
import './firebase';
import Navbar1 from './Components/Navbar/Navbar1';
import Footer from './Components/Navbar/Footer';
import Components from './Components/Pages/catalog/components';
import AddProduct from './AddProduct';

const App = () => {
  return (
   <Router>
    <Navbar1/>
    <main>
      <Switch>
        <Route path="/" exact>
          <CarouselI/>
          <Home/>
        </Route>
        <Route path="/Pagina2" exact>
          <Pagina2/>
        </Route>
        <Route path="/Pagina3">
          <Pagina3/>
        </Route>
        <Route path="/catalog/components">
          <Components/>
        </Route>
        <Route path="/AddProduct">
          <AddProduct/>
        </Route>
        <Redirect to="/" />
      </Switch>
      <Footer/>
    </main>
   </Router>
  );
}

export default App;
