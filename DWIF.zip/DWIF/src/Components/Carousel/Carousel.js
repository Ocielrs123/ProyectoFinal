import React from 'react';
import Carousel from 'react-bootstrap/Carousel';
import Img1 from './img1.jpg';
import Img2 from './img2.jpg';
import Img3 from './img3.jpg';
import Container from 'react-bootstrap/Container';



const CarouselI = () => {
    return (
<Container>
        <Carousel fade>
        <Carousel.Item>
          <img
            width="100%"
            src={Img1}
            alt="First slide"
          />
          <Carousel.Caption>
            <h2>Tienda Gamer Mamalona</h2>
            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            width="100%"
            src={Img2}
            alt="Second slide"
          />
      
          <Carousel.Caption>
            <h2>Aqui encontrarás todos lo que necesitas</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            width="100%"
            src={Img3}
            alt="Third slide"
          />
      
          <Carousel.Caption>
            <h2>Los mejores precios</h2>
            <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>
      </Container>
    );
  }
  
  export default CarouselI;