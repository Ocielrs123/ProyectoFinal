import React from 'react';
import 'react-bootstrap';

const Pagina3 = () => {
    return (
      <div className="container" >
        <h1 className="text-center" style={{ paddingTop: "30%" }} >
          Home 3
        </h1>
      </div>
    );
  }
  
  export default Pagina3;
  