import React from 'react';
import Container from 'react-bootstrap/Container';

const Pagina1 = () => {
  return (
    <Container>
    <div className="container" >
      <h1 className="text-center" style={{ paddingTop: "30%" }} >
        Home 1
      </h1>
    </div>
    </Container>
  );
}

export default Pagina1;
