import React from 'react';
import Container from 'react-bootstrap/Container';
// import '../firebase-config';

const Components = () => {
  return (
    <Container>
    <div className="container" >
      <h1>
        This is component Page
      </h1>
    </div>
    </Container>
  );
}

export default Components;
