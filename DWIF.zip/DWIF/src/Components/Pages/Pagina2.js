import React from 'react';
import Container from 'react-bootstrap/Container';
import { CardGroup, Card, Button} from 'react-bootstrap';
import { Link } from 'react-router-dom';

const Pagina2 = () => {
  return (
    <Container>
    <div className="container" >
      <h1 className="text-center" style={{ paddingTop: "30%" }} >
        Filter your search...
      </h1>
    </div>
    
    <div>
    <CardGroup>
  <Card>
    <Card.Img variant="top" src="../src/assets/img/cat1.jpg/100px100" />
    <Card.Body>
      <Card.Title>Pre-built & Laptops</Card.Title>
      <Card.Text>
        See a selection of our best gaming towers and low profile laptops
      </Card.Text>
      {/* <Button variant="info">Browse</Button> */}
    </Card.Body>
    <Button variant="info">Browse</Button>
  </Card>
  <Card>
    <Card.Img variant="top" src="holder.js/100px160" />
    <Card.Body>
      <Card.Title>Accesories</Card.Title>
      <Card.Text>
        We need tools at the height of our ability. Gear yourself to be the <strong>best</strong> 
      </Card.Text>
      {/* <Button variant="info">Browse</Button> */}
    </Card.Body>
    <Button variant="info">Browse</Button>
  </Card>
  <Card>
    <Card.Img variant="top" src="holder.js/100px160" />
    <Card.Body>
      <Card.Title>Components</Card.Title>
      <Card.Text>
        Need a new piece? There is no shortage here. Take a look.
      </Card.Text>
      {/* <Button variant="info">Browse</Button> */}
    </Card.Body>
    <Card.Link href="./catalog/components">
    <Button variant="info">Browse</Button>
    </Card.Link>
  </Card>
</CardGroup>
    </div>
    
    <br/>
    </Container>
  );
}

export default Pagina2;
