import React from 'react';
import Container from 'react-bootstrap/Container';
import { Navbar, Nav, NavItem, NavDropdown, MenuItem } from 'react-bootstrap';
import './Footer.css';

const Footer = () => {
  return (
    <Navbar expand="lg" variant="dark" bg="dark">
  <Container>
    <div className="foot">
        <h7> DevaceSoft  </h7>
    </div>
    <br/>
    <div className="foot">
        <h7> @Copyright reserved  </h7>
    </div>
  </Container>
</Navbar>
  );
}

export default Footer;