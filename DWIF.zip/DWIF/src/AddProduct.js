
import { Input } from '@material-ui/core';
import { firestore } from 'firebase-admin';
import React from 'react';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import { useState } from 'react';
import Button from 'react-bootstrap/Button';


const AddProduct = () => {
    const [ProductName,setProductName] = useState('');
    const [Quantity,setQuantity] = useState('');
    const [Price,setPrice] = useState('');
    const [Manufacturer,setManufacturer] = useState('');



    const handleAddProduct = () =>{
        const firenbase = firenbase.database().ref('/Product');
        let data = {
            ProductName:ProductName,
            Quantity:Quantity,
            Price:Price,
            Manufacturer:Manufacturer

        }
        firestore.push(data);
    }
  
  
    return (
       
    <Container>
    <div className="text-center" style={{ paddingTop: "10%" }}  >
 
        <h1>Fuck me</h1>
            <div>
                <Form>
                        <label>ProductName</label>
                        <Input placeholder="Product Name" focus value={ProductName} onChange={(e)=>{setProductName(e.target.value)}}/>
                   
                        <label>Quantity</label>
                        <Input placeholder="Product Name" focus value={Quantity} onChange={(e)=>{setQuantity(e.target.value)}}/>
                
                        <label>Price</label>
                        <Input placeholder="Product Name" focus value={Price} onChange={(e)=>{setPrice(e.target.value)}}/>
                 
                        <label>Manufacturer</label>
                        <Input placeholder="Product Name" focus value={Manufacturer} onChange={(e)=>{setManufacturer(e.target.value)}}/>

                        <Button onClick={()=>{handleAddProduct()}}> Add Product</Button>
                </Form>
            </div>

            
    </div>
    </Container>
  );
}

export default AddProduct;






