import React, {useState} from 'react';
import 'firebase/auth';
import {useFirebaseApp, useUser} from 'reactfire';
import './assets/css/style.css';
import swal from 'sweetalert';
import mono1 from './assets/images/1.png';
import mono2 from './assets/images/2.png';
import mono3 from './assets/images/3.png';
import mono4 from './assets/images/4.png';
import mono5 from './assets/images/5.png';
import Login from './Components/Login';



export default(props) => {

    
    const [email, setEmail] = useState('');

    const [password, setPassword] = useState('');

    const firebase = useFirebaseApp();

    const db = firebase.firestore();

    const user = useUser().data;


    const login = async () => {
        await firebase.auth().signInWithEmailAndPassword(email,password);
        await swal({
            title: "¡Bienvenido(a)!",
            text: "Inicio de sesión correcto",
            icon: "success",
            button: "Yei!"
        });
    }



    return(
        
        <div id="form-login1">
            <div id="monos">
                <img id="mono1" src={mono1}/>
                <img id="mono2" src={mono2}/>
                <img id="mono3" src={mono3}/>
                <img id="mono4" src={mono4}/>
                <img id="mono4" src={mono5}/>
            </div>
            {
            !user &&
            <div id="form-login2">
                <input type="email" className="inputs" placeholder="Correo electrónico" onChange={(ev) => setEmail(ev.target.value) } /><br/><br/>
                <input type="password" className="inputs" placeholder="Contraseña" onChange={(ev) => setPassword(ev.target.value) }/><br/><br/>
                <button onClick={login} id="log-log">Iniciar sesión</button>
                <Login/>
            </div>
            }
        </div>



    )
}