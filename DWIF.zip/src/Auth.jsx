import React, {useState} from 'react';
import 'firebase/auth';
import {useFirebaseApp, useUser} from 'reactfire';
import './assets/css/style.css';
import swal from 'sweetalert';
import Login from './Components/Login';
import Container from 'react-bootstrap/Container';
import Carousel from 'react-bootstrap/Carousel'
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Image from 'react-bootstrap/Image';
import img1 from './assets/images/DUI123.gif';
import Pass from './pass-reset';



export default(props) => {

    
    const [email, setEmail] = useState('');

    const [password, setPassword] = useState('');

    const firebase = useFirebaseApp();

    const db = firebase.firestore();

    const user = useUser().data;


    const login = async () => {
        await firebase.auth().signInWithEmailAndPassword(email,password);
        await swal({
            title: "¡Bienvenido(a)!",
            text: "Inicio de sesión correcto",
            icon: "success",
            button: "Yei!"
        });
    }



    return(
        <Container className="hola">
            <br/>
            <Carousel>
  <Carousel.Item>
    <img
      className="d-block w-100"
      src="https://images.pexels.com/photos/9746/people-mother-family-father.jpg?cs=srgb&dl=pexels-creative-vix-9746.jpg&fm=jpg"
      alt="First slide"
    />
    <Carousel.Caption>
      <h3>¡Conoce muchas personas!</h3>
      <p></p>
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-100"
      src="https://images.pexels.com/photos/1036804/pexels-photo-1036804.jpeg?cs=srgb&dl=pexels-afta-putta-gunawan-1036804.jpg&fm=jpg"
      alt="Second slide"
    />

    <Carousel.Caption>
      <h3>Unete a la gran comunidad</h3>
      <p>Puedes hablar, postear y mucho mas...</p>
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-100"
      src="https://images.pexels.com/photos/5158980/pexels-photo-5158980.jpeg?cs=srgb&dl=pexels-cottonbro-5158980.jpg&fm=jpg"
      alt="Third slide"
    />

    <Carousel.Caption>
      <h3>Conoce mas personas</h3>
      <p>¡Conectate con quien quieras!</p>
    </Carousel.Caption>
  </Carousel.Item>
</Carousel>
<br/>
<Form>
<Row className="justify-content-md-center">
    
    <Col md={8}>
    <Form.Group className="mb-3" controlId="formBasicEmail">
    <Form.Label>Email address</Form.Label>
    <Form.Control type="email" placeholder="Ingrese su Correo Electronico" onChange={(ev) => setEmail(ev.target.value) } />
  </Form.Group>
  </Col>
    
  </Row>
  <Row className="justify-content-md-center">
    
    <Col md={8}>
    <Form.Group className="mb-3" controlId="formBasicPassword">
    <Form.Label>Contraseña</Form.Label>
    <Form.Control type="password" placeholder="Ingrese su contraseña"onChange={(ev) => setPassword(ev.target.value) } />
    <Row id="passreset" className="justify-content-md-center">
  <Col>
  <Pass/>
  </Col>
</Row>
  </Form.Group>
  </Col>
    
  </Row>

  
<br/>

  <Row className="justify-content-md-center">
    
    <Col md="auto">
        <Button variant="success" onClick={login}>
    Iniciar Sesión
  </Button>
  </Col>
  <Col md="auto">
  <Login/> 
  </Col>
</Row>

</Form>
<br/>
        </Container>
        

    )
}