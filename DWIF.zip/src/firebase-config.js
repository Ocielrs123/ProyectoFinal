import firebase from 'firebase';
import "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyBr9mWYDneotNTlVkY9sqSq4lEaMcL1IpE",
  authDomain: "dwip2-eef21.firebaseapp.com",
  databaseURL: "https://dwip2-eef21-default-rtdb.firebaseio.com",
  projectId: "dwip2-eef21",
  storageBucket: "dwip2-eef21.appspot.com",
  messagingSenderId: "941634680772",
  appId: "1:941634680772:web:8bba8758609e1a1dd25691",
  measurementId: "G-3J6JJD6E1E"
  };

export const auth = firebase.initializeApp({
    apiKey: "AIzaSyBr9mWYDneotNTlVkY9sqSq4lEaMcL1IpE",
    authDomain: "dwip2-eef21.firebaseapp.com",
    databaseURL: "https://dwip2-eef21-default-rtdb.firebaseio.com",
    projectId: "dwip2-eef21",
    storageBucket: "dwip2-eef21.appspot.com",
    messagingSenderId: "941634680772",
    appId: "1:941634680772:web:8bba8758609e1a1dd25691",
    measurementId: "G-3J6JJD6E1E"
  }).auth()

//firebase.initializeApp(firebaseConfig);

export const storage = firebase.storage(); 

export default firebaseConfig;
