import React, {useState} from 'react';
import 'firebase/auth';
import {useFirebaseApp, useUser} from 'reactfire';
import './assets/css/style.css';
import swal from 'sweetalert';
import Button from 'react-bootstrap/Button';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';



export default(props) => {

    const firebase = useFirebaseApp();

    const user = useUser().data;

    const logout = async () =>{
       await firebase.auth().sendPasswordResetEmail().catch();
       await swal({
        title: "¡Hasta pronto!",
        text: "Cerraste tu sesión correctamente",
        icon: "success",
        button: "Adios!"
    });
    }


    return(
        <div>
            {
            user && 
            <Row className="justify-content-md-center">
                <Col md="auto">
                <Button variant="warning" onClick={logout}>¿Olvidaste tu contraseña?</Button>
                </Col>
            </Row>
            }
        </div>
    )
}