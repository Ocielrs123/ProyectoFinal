import React, {useState} from 'react';
import 'firebase/auth';
import {useFirebaseApp, useUser} from 'reactfire';
import './assets/css/style.css';
import swal from 'sweetalert';
import Button from 'react-bootstrap/Button';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Accordion from 'react-bootstrap/Accordion';
import Card from 'react-bootstrap/Card';
import { useAccordionButton } from 'react-bootstrap';
import Form from 'react-bootstrap/Form';



export default(props) => {

    const firebase = useFirebaseApp();

    const user = useUser().data;

    const [correo, setCorreo] = useState('');

    const Passreset = async () =>{
       await firebase.auth().sendPasswordResetEmail(correo).catch();
       await swal({
        title: "¡Correo enviado!",
        text: "Verifícalo",
        icon: "success",
        button: "Voy a ello!"
    });
    }

    function CustomToggle({ children, eventKey }) {
        const decoratedOnClick = useAccordionButton(eventKey, () =>
          console.log('totally custom!'),
        );
      
        return (
          <button
            type="button"
            style={{ backgroundColor: 'lightyellow' }}
            onClick={decoratedOnClick}
          >
            {children}
          </button>
        );
      }
      

      return(
        <Accordion defaultActiveKey="0">
        <Card>
          <Card.Header>
            <CustomToggle eventKey="0">¿Olvidaste tu contraseña?</CustomToggle>
          </Card.Header>
          <Accordion.Collapse eventKey="0">
            <Card.Body>
                
            <Form.Control type="email" placeholder="Ingrese su Correo Electronico" onChange={(ev)=>setCorreo(ev.target.value)} />
            <br/>
            <Button onClick={Passreset}>Enviar email</Button>

            </Card.Body>
          </Accordion.Collapse>
        </Card>
      </Accordion>
      )

    }