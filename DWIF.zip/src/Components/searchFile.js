import React, { useEffect, useState } from 'react';
import '../assets/css/style.css';
import {Redirect} from 'react-router-dom';
import { useFirebaseApp, useUser
} from 'reactfire';
import 'firebase/auth';
import Container from 'react-bootstrap/Container';
import Card from 'react-bootstrap/Card';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Image from 'react-bootstrap/Image';
import img1 from '../assets/images/email.png';
import ButtonGroup from 'react-bootstrap/ButtonGroup';
import ButtonToolbar from 'react-bootstrap/ButtonToolbar';
import Button from 'react-bootstrap/Button';
import InputGroup from 'react-bootstrap/InputGroup';
import FormControl from 'react-bootstrap/FormControl';


const PostFile = () => {
    const firebase = useFirebaseApp();
    const db = firebase.firestore();
    const [blogs,setBlogs]=useState([]);
    let img = img1;
    const [user, setUser] = useState({});
  const auth = useUser().data;

  const [titulo, setTitulo] = useState('');

  const caca = () => {
    this.render();
  }

  const fetchBlogs=async()=>{
    const citiesRef = db.collection('post').where('Autor','==', titulo);
    const snapshot = await citiesRef.get();
    snapshot.forEach(doc => {
    setBlogs(prev => [...prev, doc.data()]) 

   
});

  }

  //if(){
  useEffect(() => {
    fetchBlogs();
  }, [])
  //}

  return (
    <div className="home-css">
       
          {
            !user &&
              <Redirect to="/Auth"/>
          }
          <div className="left"></div>
          <div className="center">
          <br/>
          <Container>
          <br/>
          <ButtonToolbar className="mb-3" aria-label="Toolbar with Button groups">
          <ButtonGroup className="me-2" aria-label="First group">
          <InputGroup>
           <FormControl
             type="text"
             placeholder="Buscar nombre del autor"
            aria-label="Buscar nombre del autor"
           aria-describedby="btnGroupAddon"
           onChange={(ev) => setTitulo(ev.target.value)}
           />
           </InputGroup>
           <Button variant="secondary" onClick={fetchBlogs}>Buscar</Button>
          </ButtonGroup>
          <Button variant="primary" href="/" to="/">Regresar</Button>
        </ButtonToolbar>
          <br/>
          {
        
        blogs && blogs.map((blog)=>{
          //console.log(blogs);
          if(blog.Imagen != null){
            img = blog.Imagen;
          }
          
          return(
            <div>
            <Row> 
            <Col xs={6} md={4}>
            <Image src={img} thumbnail />
           </Col>
           <Col>
            <Card style={{ width: '100%', height: '100%' }}>
             <Card.Body>
             <Card.Title>{blog.Titulo}</Card.Title>
             <Card.Subtitle className="mb-2 text-muted">Por: {blog.Autor}</Card.Subtitle>
             <Card.Subtitle className="mb-2 text-muted">Fecha: {blog.Fecha}</Card.Subtitle> 
           <Card.Text>
            {blog.Contenido}
           </Card.Text>
           <Card.Link href="/Pagina3" to="/Pagina3">Card Link</Card.Link>
             <Card.Link href="#">Another Link</Card.Link>
            </Card.Body>
           </Card>
           </Col>
             </Row>
             <br/>
             </div>

          ) 
        })
       
      }
      
          </Container>
    
          </div>
          <div className="right"></div>
          
     </div>
  );
}

export default PostFile;