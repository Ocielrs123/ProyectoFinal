import React, { useEffect, useState } from 'react';
import '../assets/css/style.css';
import {Redirect} from 'react-router-dom';
import {firestore, useFirebaseApp, useFirestoreDoc, useUser} from 'reactfire';
import 'firebase/auth';
import Container from 'react-bootstrap/Container';
//import {firestore, useFirebaseApp, useFirestoreDoc, useUser} from 'reactfire';
import swal from 'sweetalert';
import 'firebase/storage';
import {storage} from "../firebase-config";
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';



export default (props) => {

    const [titulo, setTitulo] = useState('');

    const [contenido, setCont] = useState('');

    let [imagen, setImg] = useState('');

    /*if(imagen == ''){
      imagen = null;
    }*/
    //////////////////////////////////////////////////777
    const [image, setImage] = useState(null);

    const onImageChange = (e) => {
      const reader = new FileReader();
      let file = e.target.files[0]; // get the supplied file
      // if there is a file, set image to that file
      if (file) {
        reader.onload = () => {
          if (reader.readyState === 2) {
            console.log(file);
            setImage(file);
          }
        };
        reader.readAsDataURL(e.target.files[0]);
      // if there is no file, set image back to null
      } else {
        setImage(null);
      }
    };

    const submitImage = () => {
      //1.
      if (image) {
        //2.
        const storageRef = storage.ref('/images');
        //3.
        const imageRef = storageRef.child(image.name);
        //4.
        imageRef.put(image)
       //5.
       .then(() => {
        getUrl();
    });
    } else {
      alert("Please upload an image first.");
      }
    }

    const getUrl = () => {
      const imageRef = firebase.storage().ref(`/images/${image.name}`); 
      imageRef.getDownloadURL().then((url) => {
        submit(url);
      })
    }

    ////////////////////////////////////////////////7777777
    const firebase = useFirebaseApp();

    const db = firebase.firestore();

    const auth = useUser().data;

    const user = useUser().data;

    useEffect(()=>{
    db.collection('users')
      .doc(auth.uid)
      .onSnapshot((doc) => setUser({
        ...doc.data(),
        email: auth.email
      }))
    }, []);

    const [usuario, setUser] = useState({});

    const persona = usuario.Nombre+' '+usuario.Ape;

    let today = new Date();

    let date=today.getDate() + "/"+ parseInt(today.getMonth()+1) +"/"+today.getFullYear();

    const submit = async (url) =>{
            return db.collection('post').doc().set({
                Titulo: titulo,
                Contenido: contenido,
                Fecha: date,
                Autor: persona,
                Imagen: url,
            }).then(
                await swal({
                  title:"¡Post creado!",
                  icon:"success",
                  button:"OK"
                }).then(function() {
                  window.location = "/";
              })
            );}


  return (
    <div>
    <div className="left"></div>
      <Container className="center2">
          {
            !user &&
              <Redirect to="/Auth"/>
          }
    <div>
            <div>
              <br/>
            <Form>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                <Form.Label>Titulo</Form.Label>
                <Form.Control type="text" placeholder="¿Que estas pensando?" required id="titulo" onChange={(ev) => setTitulo(ev.target.value) } />
            </Form.Group>
           <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                <Form.Label>Compartenos que piensas</Form.Label>
                <Form.Control as="textarea" rows={3} required id="contenido" onChange={(ev) => setCont(ev.target.value) } />
            </Form.Group>
            <Form.Group controlId="formFile" className="mb-3">
                <Form.Label>Comparte una foto</Form.Label>
                <Form.Control type="file" id="imagen" accept="image/x-png,image/jpeg" onChange={(e) => {onImageChange(e); }}/>
            </Form.Group>
            <Row className="justify-content-md-center">
                <Col md="auto">
                    <Button variant="success" onClick={submit, submitImage}>
                    Crear Post
                    </Button>
                </Col>
              </Row>
            </Form>
            <br/>
            </div>
        </div>
        </Container>
        <div className="right"></div>
        </div>
  );
}
