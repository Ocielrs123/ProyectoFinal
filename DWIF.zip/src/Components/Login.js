import React from "react";
import { GoogleOutlined } from '@ant-design/icons';
import firebase from "firebase/app";
import Button from 'react-bootstrap/Button';
import swal from 'sweetalert';
import { auth } from "../firebase-config"

export default function Login() {
  return (
        <div>
          <Button variant="primary" onClick={() => auth.signInWithPopup(new firebase.auth.GoogleAuthProvider())}><GoogleOutlined /> Sign In with Google</Button>
        </div>
  )
}
