import React, { useEffect, useState } from 'react';
import '../assets/css/style.css';
import {Redirect} from 'react-router-dom';
import {firestore, useFirebaseApp, useFirestoreDoc, useUser} from 'reactfire';
import 'firebase/auth';
import swal from 'sweetalert';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import '../assets/css/style.css';
import {storage} from "../firebase-config";
import Image from 'react-bootstrap/Image';


  export default (props) => {

  const [user, setUser] = useState({});

  const auth = useUser().data;

  const firebase = useFirebaseApp();

  const db = firebase.firestore();

  const [Dato1,setDato1] = useState('');

  const [Dato2,setDato2] = useState('');

  useEffect(()=>{
    db.collection('users')
      .doc(auth.uid)
      .onSnapshot((doc) => setUser({
        ...doc.data(),
        email: auth.email
      }))
  }, []);

    //////////////////////////////////////////////////777
    const [image, setImage] = useState(null);

    const onImageChange = (e) => {
      const reader = new FileReader();
      let file = e.target.files[0]; // get the supplied file
      // if there is a file, set image to that file
      if (file) {
        reader.onload = () => {
          if (reader.readyState === 2) {
            console.log(file);
            setImage(file);
          }
        };
        reader.readAsDataURL(e.target.files[0]);
      // if there is no file, set image back to null
      } else {
        setImage(null);
      }
    };
  
    const submitImage = () => {
      //1.
      if (image) {
        //2.
        const storageRef = storage.ref('/Perfil');
        //3.
        const imageRef = storageRef.child(image.name);
        //4.
        imageRef.put(image)
       //5.
       .then(() => {
        getUrl();
    });
    } else {
      alert("Please upload an image first.");
      }
    }
  
    const getUrl = () => {
      const imageRef = firebase.storage().ref(`/Perfil/${image.name}`); 
      imageRef.getDownloadURL().then((url) => {
      actualizar(url);
      })
    }
  
    ////////////////////////////////////////////////////////


  const actualizar = async (url) => {
    return db.collection('users').doc(auth.uid).set({
      Nombre:Dato1,
      Ape:Dato2,
      Imagen:url,
    }).then(
      await swal({
        title:"¡Datos actualizados!",
        icon:"success",
        button:"OK"
      })
    );

  }

  return (
    <div className="container" >
      {
        user &&
        <div>
  
            <center>
            <Container className="center4">
          {
            !user &&
              <Redirect to="/Auth"/>
          }
    <div>
            <div>
              <br/>
            <Row className="justify-content-md-center">
    
              <Col md="auto">
              <Image src={user.Imagen} thumbnail/>
              </Col>
            </Row>
              <br/>
            <Form>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                <Form.Label>Nombre</Form.Label>
                <Form.Control type="text" name="Nom" required placeholder={user.Nombre} id="nombre" onChange={(ev)=>setDato1(ev.target.value)}/>
            </Form.Group>
           <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                <Form.Label>Apellidos</Form.Label>
                <Form.Control type="text" name="Apellidos" required placeholder={user.Ape} id="apellidos" onChange={(ev)=>setDato2(ev.target.value)} />
            </Form.Group>
            <Form.Group controlId="formFile" className="mb-3">
                <Form.Label>Correo</Form.Label>
                <Form.Control type="text" placeholder={user.email} disabled/>
            </Form.Group>
            <Form.Group controlId="formFile" className="mb-3">
                <Form.Label>Comparte una foto</Form.Label>
                <Form.Control type="file" id="imagen" required accept="image/x-png,image/jpeg" onChange={(e) => {onImageChange(e); }}/>
            </Form.Group>
            <Row className="justify-content-md-center">
                <Col md="auto">
                    <Button variant="success"  onClick={submitImage}>
                    Actualizar Datos
                    </Button>
                </Col>
              </Row>
            </Form>
            <br/>
            </div>
        </div>
        </Container>
            </center>
           
          </div>          
     
      }
      
    </div>
  );
}