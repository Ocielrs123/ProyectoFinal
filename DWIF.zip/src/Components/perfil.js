import React, { useEffect, useState } from 'react';
import '../assets/css/style.css';
import {Redirect} from 'react-router-dom';
import {firestore, useFirebaseApp, useFirestoreDoc, useUser} from 'reactfire';
import Auth from '../Auth';
import 'firebase/auth';
import AuthCreate from '../AuthCreate';
import Fconfig from '../firebase-config';
import ReactDOMServer from 'react-dom/server';
import pp from '../assets/images/pp.png';
import swal from 'sweetalert';


  export default (props) => {

  const [user, setUser] = useState({});

  const auth = useUser().data;

  const firebase = useFirebaseApp();

  const db = firebase.firestore();

  const [Dato1,setDato1] = useState('');

  const [Dato2,setDato2] = useState('');

  useEffect(()=>{
    db.collection('users')
      .doc(auth.uid)
      .onSnapshot((doc) => setUser({
        ...doc.data(),
        email: auth.email
      }))
  }, []);


  const update = async () => {
    return db.collection('users').doc(auth.uid).update({
      Nombre:Dato1,
      Ape:Dato2,
    }).then(
      await swal({
        title:"¡Datos actualizados!",
        icon:"success",
        button:"OK"
      })
    );

  }

  return (
    <div className="container" >
      {
        user &&
        <div>
          <div id="izq">
            <center>
            <img src={pp} id="pp"/>
            <h1 className="text-center" style={{ paddingTop: "10%", paddingBottom:"0px", color:"black", display:"inline-block", paddingLeft:"50px"}} >Hola!</h1>

              <div style={{paddingTop:"5%"}}>
                <form>
                <label>Tu correo es:</label>
                <input className="inputs" placeholder={user.email} disabled/><br/><br/>

                <label>Tu nombre es:</label>
                <input className="inputs" name="Nom" placeholder={user.Nombre} id="nombre" onChange={(ev)=>setDato1(ev.target.value)}/><br/><br/>
                
                <label>Tus apellidos son:</label>
                <input className="inputs" name="Apellidos" placeholder={user.Ape} id="apellidos" onChange={(ev)=>setDato2(ev.target.value)}/><br/><br/>
                </form>
              </div>
              </center>
          </div>
          <div id="der">
            <center>
            <button id="actualizar-log" onClick={update}>Actualizar datos</button>
            </center>
          </div>          
        </div>
      }
    </div>
  );
}