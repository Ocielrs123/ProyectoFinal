import React, { useEffect, useState } from 'react';
import '../assets/css/style.css';
import {Redirect} from 'react-router-dom';
import { useFirebaseApp, useUser
} from 'reactfire';
import 'firebase/auth';
import Container from 'react-bootstrap/Container';
import ButtonGroup from 'react-bootstrap/ButtonGroup';
import ButtonToolbar from 'react-bootstrap/ButtonToolbar';
import Button from 'react-bootstrap/Button';
import InputGroup from 'react-bootstrap/InputGroup';
import FormControl from 'react-bootstrap/FormControl';
import PostFile from './postFile';


const Home = () => {

  const [titulo, setTitulo] = useState('');

  

  const [user, setUser] = useState({});

  const firebase = useFirebaseApp();

  return (
    <div className="home-css">
          {
            !user &&
              <Redirect to="/Auth"/>
          }
          <div className="left"></div>
          <div className="center">
          <Container>
      <br/>
      <ButtonToolbar className="mb-3" aria-label="Toolbar with Button groups">
      <ButtonGroup className="me-2" aria-label="First group">
      <Button variant="primary" href="/crearpost" to="/crearpost">Crear Post</Button>
    </ButtonGroup>
    <InputGroup>
      <FormControl
        type="text"
        placeholder="Buscar Post"
        aria-label="Input group example"
        aria-describedby="btnGroupAddon"
        onChange={(ev) => setTitulo(ev.target.value) }
      />
      <InputGroup.Text id="btnGroupAddon">Buscar</InputGroup.Text>
    </InputGroup>
  </ButtonToolbar>
    <br/>
        <PostFile/>
      <br/>
    </Container>
    
          </div>
          <div className="right"></div>
          
     </div>
  );
}

export default Home;
