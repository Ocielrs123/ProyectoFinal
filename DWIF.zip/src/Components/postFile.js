import React, { useEffect, useState } from 'react';
import '../assets/css/style.css';
import {Redirect} from 'react-router-dom';
import { useFirebaseApp, useUser
} from 'reactfire';
import 'firebase/auth';
import Container from 'react-bootstrap/Container';
import Card from 'react-bootstrap/Card';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Image from 'react-bootstrap/Image';
import img1 from '../assets/images/email.png';


const PostFile = () => {
    const firebase = useFirebaseApp();
    const db = firebase.firestore();
    const [blogs,setBlogs]=useState([]);
    let img = img1;
    const [user, setUser] = useState({});
  const auth = useUser().data;

  const fetchBlogs=async()=>{
    const citiesRef = db.collection('post');
    const snapshot = await citiesRef.get();
    snapshot.forEach(doc => {
    setBlogs(prev => [...prev, doc.data()])
});

  }

  //if(){
  useEffect(() => {
    fetchBlogs();
  }, [])
  //}

  return (
    <div className="App">
      {
        
        blogs && blogs.map((blog)=>{
          //console.log(blogs);
          if(blog.Imagen != null){
            img = blog.Imagen;
          }
          
          return(

            <Row> 
            <Col xs={6} md={4}>
            <Image src={img} thumbnail />
           </Col>
           <Col>
            <Card style={{ width: '100%', height: '100%' }}>
             <Card.Body>
             <Card.Title>{blog.Titulo}</Card.Title>
             <Card.Subtitle className="mb-2 text-muted">Por: {blog.Autor}</Card.Subtitle>
             <Card.Subtitle className="mb-2 text-muted">Fecha: {blog.Fecha}</Card.Subtitle> 
           <Card.Text>
            {blog.Contenido}
           </Card.Text>
           <Card.Link href="/Pagina3" to="/Pagina3">Card Link</Card.Link>
             <Card.Link href="#">Another Link</Card.Link>
            </Card.Body>
           </Card>
           </Col>
             </Row>
          ) 
        })
       
      }
    </div>
  );
  
}

export default PostFile;