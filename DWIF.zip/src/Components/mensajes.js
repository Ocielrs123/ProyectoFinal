import React from 'react';
import '../assets/css/style.css';
import {Redirect} from 'react-router-dom';
import {
  useFirebaseApp,
  useUser
} from 'reactfire';
import 'firebase/auth';


const Mensajes = () => {
  const user = useUser().data;
  const firebase = useFirebaseApp();
  return (
    <div className="container" >
      {
        !user &&
          <Redirect to="/Auth"/>
      }
      <h1 className="text-center" style={{ paddingTop: "30%" }} >
        Mensajes
      </h1>
    </div>
  );
}

export default Mensajes;
