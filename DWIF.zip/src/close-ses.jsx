import React, {useState} from 'react';
import 'firebase/auth';
import {useFirebaseApp, useUser} from 'reactfire';
import './assets/css/style.css';
import swal from 'sweetalert';


export default(props) => {

    const firebase = useFirebaseApp();

    const user = useUser().data;

    const logout = async () =>{
       await firebase.auth().signOut().catch();
       await swal({
        title: "¡Hasta pronto!",
        text: "Cerraste tu sesión correctamente",
        icon: "success",
        button: "Adios!"
    });
    }


    return(
        <div id="cerrar-ses">
            {
            user && 
            <button onClick={logout} id="close-sesion">Cerrar sesión</button>
            }
        </div>
    )
}