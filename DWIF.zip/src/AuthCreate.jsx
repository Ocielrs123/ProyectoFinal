import React, {useState} from 'react';
import 'firebase/auth';
import {useFirebaseApp, useUser} from 'reactfire';
import './assets/css/style.css';
import swal from 'sweetalert';
import mono1 from './assets/images/1.png';
import mono2 from './assets/images/2.png';
import mono3 from './assets/images/3.png';
import mono4 from './assets/images/4.png';
import mono5 from './assets/images/5.png';
import  './firebase-config';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Carousel from 'react-bootstrap/Carousel'
import ReCAPTCHA from "react-google-recaptcha";




export default(props) => {

    
    const [email, setEmail] = useState('');

    const [password, setPassword] = useState('');

    const [Nombre, setNombre] = useState('');

    const [Apellidos, setAppellidos] = useState('');

    const firebase = useFirebaseApp();

    const db = firebase.firestore();

    const user = useUser().data;

    const submit = async () =>{
        await firebase.auth().createUserWithEmailAndPassword(email,password).then(cred =>{
            return db.collection('users').doc(cred.user.uid).set({
                Nombre: Nombre,
                Ape: Apellidos,
            });
        });
        
        await swal({
            title: "¡Cuenta creada!",
            icon: "success",
            button: "Yei!"
        });

        await firebase.auth().currentUser.sendEmailVerification().then(() => {
            console.log("Email de verifiación enviado")
        })
    }



    return(
        
        <div>
            {
            !user &&
            <div>
                <br/>
                <Container>
                <Row>
                <Col>
                <Carousel className="hola2">
                <Carousel.Item>
                <img
                 className="d-block w-100"
                    id="hola3"
                    src={mono1}
                    alt="First slide"
                />
                </Carousel.Item>
                <Carousel.Item>
                 <img
                 className="d-block w-100"
                 id="hola3"
                     src={mono4}
                        alt="Second slide"
                    />
                </Carousel.Item>
                <Carousel.Item>
                <img
                    className="d-block w-100"
                    id="hola3"
                    src={mono5}
                    alt="Third slide"
                />
                </Carousel.Item>
                </Carousel>
                </Col>
                <Col className="hola1">
                <br/>
                <Form>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                <Form.Label>Nombre</Form.Label>
                <Form.Control type="text" name="Nom" required placeholder="Nombres" id="nombre" required onChange={(ev) => setNombre(ev.target.value) }/>
                </Form.Group>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                <Form.Label>Apellidos</Form.Label>
                <Form.Control type="text" name="Apellidos" required placeholder="Apellidos" id="apellidos" required onChange={(ev) => setAppellidos(ev.target.value) } />
                </Form.Group>
                <Form.Group controlId="formFile" className="mb-3">
                <Form.Label>Correo</Form.Label>
                <Form.Control type="email" placeholder="Correo" required onChange={(ev) => setEmail(ev.target.value) }/>
                </Form.Group>
                <Form.Group controlId="formFile" className="mb-3">
                <Form.Label>Contraseña</Form.Label>
                <Form.Control type="password" placeholder="Contraseña" required onChange={(ev) => setPassword(ev.target.value) }/>
                </Form.Group>
                <Row className="justify-content-md-center">
                <Col md="auto">
                <ReCAPTCHA sitekey="6LeKZZQaAAAAAAWax8vjJPpfC4R-NKsaBOxx_FAq" type="image"/>
                </Col>
                </Row>
                <Row className="justify-content-md-center">
                <Col md="auto">
                    <Button variant="success" onClick={submit}>
                    Crear Usuario
                    </Button>
                </Col>
                </Row>
                </Form>
                </Col>
                </Row>
                </Container>

            </div>
            
            }
        </div>



    )
}