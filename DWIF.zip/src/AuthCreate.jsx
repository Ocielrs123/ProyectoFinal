import React, {useState} from 'react';
import 'firebase/auth';
import {useFirebaseApp, useUser} from 'reactfire';
import './assets/css/style.css';
import swal from 'sweetalert';
import mono1 from './assets/images/1.png';
import mono2 from './assets/images/2.png';
import mono3 from './assets/images/3.png';
import mono4 from './assets/images/4.png';
import mono5 from './assets/images/5.png';
import  './firebase-config';



export default(props) => {

    
    const [email, setEmail] = useState('');

    const [password, setPassword] = useState('');

    const [Nombre, setNombre] = useState('');

    const [Apellidos, setAppellidos] = useState('');

    const [Edad, setEdad] = useState('');

    const [Telefono, setTelefono] = useState('');

    const [Calle, setCalle] = useState('');

    const [Numero, setNumero] = useState('');

    const [CP, setCP] = useState('');

    const firebase = useFirebaseApp();

    const db = firebase.firestore();

    const user = useUser().data;

    const submit = async () =>{
        await firebase.auth().createUserWithEmailAndPassword(email,password).then(cred =>{
            return db.collection('users').doc(cred.user.uid).set({
                Nombre: Nombre,
                Ape: Apellidos,
                Edad: Edad,
                Tel: Telefono,
                Calle: Calle,
                Num: Numero,
                CP: CP,
            });
        });
        
        await swal({
            title: "¡Cuenta creada!",
            icon: "success",
            button: "Yei!"
        });

        await firebase.auth().currentUser.sendEmailVerification().then(() => {
            console.log("Email de verifiación enviado")
        })
    }



    return(
        
        <div id="form-login1">
            <div id="monos">
                <img id="mono1" src={mono1}/>
                <img id="mono2" src={mono2}/>
                <img id="mono3" src={mono3}/>
                <img id="mono4" src={mono4}/>
                <img id="mono4" src={mono5}/>
            </div>
            {
            !user &&
            <div id="form-login2">
                <form>
                <input type="email" className="inputs" placeholder="Correo electrónico" required onChange={(ev) => setEmail(ev.target.value) } /><br/><br/>
                <input type="password" className="inputs" placeholder="Contraseña"required onChange={(ev) => setPassword(ev.target.value) } /><br/><br/>
                <input type="text" className="inputs" placeholder="Nombre(s)" required onChange={(ev) => setNombre(ev.target.value) }  /><br/><br/>
                <input type="text" className="inputs" placeholder="Apellidos" required onChange={(ev) => setAppellidos(ev.target.value) }  /><br/><br/>
                <input type="text" className="inputs" placeholder="Edad" required onChange={(ev) => setEdad(ev.target.value) }  /><br/><br/>
                <input type="text" className="inputs" placeholder="Telefono" required onChange={(ev) => setTelefono(ev.target.value) }  /><br/><br/>
                <input type="text" className="inputs" placeholder="Calle" required onChange={(ev) => setCalle(ev.target.value) }  /><br/><br/>
                <input type="text" className="inputs" placeholder="Numero" required onChange={(ev) => setNumero(ev.target.value) }  /><br/><br/>
                <input type="text" className="inputs" placeholder="Codigo Postal" required onChange={(ev) => setCP(ev.target.value) }  /><br/><br/>
                </form>
                <button id="crear-log" value="Crear cuenta" onClick={submit}/>
            </div>
            }
        </div>



    )
}