import React, { useState, useEffect } from 'react';
import {
  BrowserRouter as Router,
  Redirect,
  Route,
  Switch,
  useHistory
} from 'react-router-dom';
import Mensajes from './Components/mensajes';
import postCreate from './Components/postCreate';
import Navbar from './Components/Navbar';
import Perfil from './Components/perfil';
import Home from './Components/home';
import Auth from './Auth';
import AuthCreate from './AuthCreate';
import './assets/css/style.css';
import {
  useFirebaseApp,
  useUser
} from 'reactfire';
import 'firebase/auth';
import Close from './close-ses';
import './firebase-config';

import Chats from "./Components/Chats"
import Login from "./Components/Login"
import { AuthProvider } from "./contexts/AuthContext"
import PostCreate from './Components/postCreate'

const App = () => {
  const [user, setUser] = useState({})
  const auth = useUser().data;
  const firebase = useFirebaseApp();
  const db = firebase.firestore();
  const tohome = <Redirect to="/home"/>

  ////////////////////////////////////////////////////////////////////////////

  ////////////////////////////////////////////////////////////////////////////

  ////////////////////////////////////////////////////////////////////////////

  return (
    <Router>
    <AuthProvider>
   <Navbar/>
   <main>
     <Switch>
       <Route exact path="/" component={Home}/>
       <Route exact path="/mensajes" component={Mensajes}/>
       <Route exact path="/crearpost" component={PostCreate}/>
       <Route path="/chats" component={Chats} >
       {
           !auth &&
             <Auth/>
         }
       {
           auth &&
             <Chats component={Chats} />
         }

       </Route> 
       <Route path="/Login" component={Login} >
       {
           !auth &&
             <Auth/>
         }
       {
           auth &&
             <Login user={Login} />
         }
       </Route> 
       <Route exact path="/perfil">
         {
           !auth &&
           <div>
             <Auth/> 
           </div>
         }
         {
           auth &&
             <Perfil user={user} />
         }
         
       </Route> 
       <div id="auth-log">
         <Route path="/Auth" exact>
           {
             auth &&
               <div id="auth-logs">
                 <b><p id="user-log">¡Hola!, iniciaste sesión como: {auth.email}</p></b>
                 <Close/>
               </div>
           }
           {
             !auth &&
             <Auth/>
           }
         </Route>
         <Route path="/AuthCreate" exact>
           {
             auth &&
             <div id="auth-logs">
               <b><p id="user-log">¡Hola!, iniciaste sesión como: {auth.email}</p></b>
               <Close/>
             </div>
           }
           {
             !auth &&
             <AuthCreate/>
           }
         </Route>
      </div>
     </Switch>
   </main>
   </AuthProvider>
  </Router>
 );
}


export default App;
